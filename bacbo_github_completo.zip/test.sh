#!/bin/bash
# Script para testar o bot do Telegram localmente

echo "Iniciando teste do bot do Telegram..."
python3 main.py
