# BacBo Telegram Bot

Sistema automatizado para enviar sinais do jogo Bac Bo para o Telegram.

## Funcionalidades

- Simulação de resultados do jogo Bac Bo
- Envio automático de resultados para o grupo do Telegram
- Análise estatística dos resultados
- Detecção de padrões
- Funcionamento 24/7 na SquareCloud

## Configuração

O sistema já está configurado com:
- Token do bot: 8031091078:AAGlssJNfyndW09Enmbm4auuW9t9x6zTv7k
- ID do chat: -1002467452947

## Como usar

1. Importe este repositório diretamente para a SquareCloud
2. O sistema iniciará automaticamente
3. Os resultados serão enviados para o grupo do Telegram a cada 60 segundos

## Arquivos

- `main.py`: Script principal com o simulador e integração com Telegram
- `requirements.txt`: Dependências do projeto
- `squarecloud.app`: Configuração para a SquareCloud

## Hospedagem

Este projeto foi desenvolvido para ser hospedado na SquareCloud através de importação direta do GitHub.
